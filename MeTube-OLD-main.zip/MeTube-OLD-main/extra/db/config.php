<?php
$host = 'localhost'; //Хост MYSQL, можно и так оставить localhost
$username = 'user'; //Имя пользователя MYSQL
$pwd = 'pwd'; //Пароль MYSQL
$db = 'db'; //Название базы данных, обязательно импортируйте metube.sql в бд!
?>