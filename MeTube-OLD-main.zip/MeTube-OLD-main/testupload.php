<form action="upload_file.php" id="uploadForm" name="frmupload" method="POST" enctype="multipart/form-data">
<input type="file" accept="video/*"  name="video_file" id="file_vid">
                                <input name="sumbit" type="submit" >
</form>