<?php
header("Location: /login");
?>